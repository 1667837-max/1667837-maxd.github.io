# 环枢 IncluOpt · 药品包合工艺优化实验平台（静态部署版）

纯前端、零依赖、零后端的药品包合工艺优化实验软件。包含三大专业模块：

1. **初筛哨探 FactorScreen** —— 模仿 Plackett-Burman 筛选，含中心点重复与曲率检验。
2. **曲面寻优 SurfaceOpt** —— 模仿 Box-Behnken 响应曲面建模，含拟合不足检验(LoF)与边界最优点诊断。
3. **效能核算 YieldCheck** —— 包合率自动计算，含可选定义、物料平衡校验、蒙特卡洛不确定度。

本目录是**可直接部署的静态包**，无需任何构建步骤、无需服务器，任何静态托管都能跑。

---

## 部署方式（任选其一，均免登录公开访问）

### 方式 A：GitHub Pages（免费、长期稳定，需 GitHub 账号）

1. 在 GitHub 新建一个空仓库（例如 `incluopt`）。
2. 进入本目录，初始化并提交（把 `YOUR_USERNAME/incluopt` 换成你的仓库地址）：
   ```bash
   git init
   git add -A
   git commit -m "环枢 IncluOpt 静态部署"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/incluopt.git
   git push -u origin main
   ```
3. 仓库 → Settings → Pages → Source 选 **main** 分支、目录 **/ (root)** → Save。
4. 几分钟后访问 `https://YOUR_USERNAME.github.io/incluopt/`，即公开链接。

> 注意：仓库请设为 **Public**，否则 Pages 不对外公开。

### 方式 B：Netlify Drop（最省事，拖一下就出链接，需 Netlify 账号）

1. 打开 https://app.netlify.com/drop
2. 把本目录整个拖进去。
3. 立刻得到公开 URL，任何人免登录直接访问。

### 方式 C：Vercel（免费，需 Vercel 账号）

1. 打开 https://vercel.com/new
2. 上传本目录（或连 Git 仓库）。
3. Framework 选 **Other / 静态**，Deploy。
4. 得到公开 URL。

---

## 本地预览（不部署也能看）

任选其一：
```bash
# 方式 1：Python 自带服务器
python -m http.server 8080
# 浏览器打开 http://localhost:8080/

# 方式 2：Node（见同工作区的 serve.js，不随本包发布）
node serve.js
```

---

## 文件说明

| 文件 | 作用 |
|---|---|
| `index.html` | 页面结构与三模块标签 |
| `styles.css` | 界面样式 |
| `app.js` | 交互逻辑、表格、图表、统计输出 |
| `mathlib.js` | 纯数学核心（PB/BBD 设计、最小二乘、ANOVA、t/F 分布、最优化、蒙特卡洛），浏览器与 Node 通用 |
| `.nojekyll` | 告诉 GitHub Pages 不要启用 Jekyll 处理 |

> 完整方法学、公式与算法说明见原工作区的《平台设计分析与改进白皮书.md》。
