/* =============================================================================
 * mathlib.js — 药品包合工艺优化实验软件 · 纯数学核心库
 * 不依赖任何 DOM，可在浏览器与 Node 中复用。
 *
 * 包含：
 *   1) 矩阵/线性代数工具
 *   2) Plackett-Burman (PB) 筛选设计生成 + 主效应 + Lenth 显著性检验
 *   3) Box-Behnken (BBD) 设计生成 + 二阶响应曲面建模 (最小二乘 / ANOVA)
 *   4) 网格最优化 / 驻点求解 (预测最优工艺)
 *   5) 学生 t / F 分布 (用于 p 值)
 * ===========================================================================*/
(function (root) {
  'use strict';

  /* ---------------------------- 基础统计工具 ----------------------------- */
  function median(arr) {
    const a = arr.slice().sort((x, y) => x - y);
    const n = a.length;
    if (n === 0) return 0;
    const mid = Math.floor(n / 2);
    return n % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
  }
  function mean(arr) { return arr.reduce((s, v) => s + v, 0) / (arr.length || 1); }

  /* ---------------------------- 线性代数工具 ----------------------------- */
  function transpose(M) {
    const r = M.length, c = M[0].length;
    const T = Array.from({ length: c }, () => Array(r).fill(0));
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) T[j][i] = M[i][j];
    return T;
  }
  function matMul(A, B) {
    const rA = A.length, cA = A[0].length, cB = B[0].length;
    const C = Array.from({ length: rA }, () => Array(cB).fill(0));
    for (let i = 0; i < rA; i++)
      for (let j = 0; j < cB; j++) {
        let s = 0;
        for (let k = 0; k < cA; k++) s += A[i][k] * B[k][j];
        C[i][j] = s;
      }
    return C;
  }
  // 高斯-约当消元求逆（带部分主元）
  function matInv(A) {
    const n = A.length;
    const M = A.map((row, i) => row.concat(Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))));
    for (let col = 0; col < n; col++) {
      let piv = col;
      for (let r = col + 1; r < n; r++) if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
      if (Math.abs(M[piv][col]) < 1e-12) throw new Error('矩阵不可逆');
      [M[col], M[piv]] = [M[piv], M[col]];
      const d = M[col][col];
      for (let j = 0; j < 2 * n; j++) M[col][j] /= d;
      for (let r = 0; r < n; r++) {
        if (r === col) continue;
        const f = M[r][col];
        if (f === 0) continue;
        for (let j = 0; j < 2 * n; j++) M[r][j] -= f * M[col][j];
      }
    }
    return M.map((row) => row.slice(n));
  }
  function solveLinear(A, b) {
    // 返回 A x = b 的解（高斯消元）
    const n = A.length;
    const M = A.map((row, i) => row.concat([b[i]]));
    for (let col = 0; col < n; col++) {
      let piv = col;
      for (let r = col + 1; r < n; r++) if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
      [M[col], M[piv]] = [M[piv], M[col]];
      const d = M[col][col];
      for (let j = col; j <= n; j++) M[col][j] /= d;
      for (let r = 0; r < n; r++) {
        if (r === col) continue;
        const f = M[r][col];
        if (f === 0) continue;
        for (let j = col; j <= n; j++) M[r][j] -= f * M[col][j];
      }
    }
    return M.map((row) => row[n]);
  }

  // 对称矩阵 Jacobi 特征值分解（用于伪逆，避免秩亏设计矩阵崩溃）
  function jacobiEigen(Ain) {
    const n = Ain.length;
    const A = Ain.map((r) => r.slice());
    const V = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));
    for (let sweep = 0; sweep < 100; sweep++) {
      let off = 0;
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) off += A[i][j] * A[i][j];
      if (off < 1e-14) break;
      for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) {
        if (Math.abs(A[p][q]) < 1e-15) continue;
        const phi = 0.5 * Math.atan2(2 * A[p][q], A[q][q] - A[p][p]);
        const c = Math.cos(phi), s = Math.sin(phi);
        for (let i = 0; i < n; i++) {
          const aip = A[i][p], aiq = A[i][q];
          A[i][p] = c * aip - s * aiq; A[i][q] = s * aip + c * aiq;
        }
        for (let i = 0; i < n; i++) {
          const api = A[p][i], aqi = A[q][i];
          A[p][i] = c * api - s * aqi; A[q][i] = s * api + c * aqi;
        }
        for (let i = 0; i < n; i++) {
          const vip = V[i][p], viq = V[i][q];
          V[i][p] = c * vip - s * viq; V[i][q] = s * vip + c * viq;
        }
      }
    }
    const values = []; for (let i = 0; i < n; i++) values.push(A[i][i]);
    return { values, vectors: V };
  }
  // 对称半正定矩阵的 Moore-Penrose 伪逆
  function pinvSym(A) {
    const { values, vectors: V } = jacobiEigen(A);
    const n = A.length;
    const tol = n * Math.max(1e-300, ...values.map(Math.abs)) * 1e-12 + 1e-14;
    const P = Array.from({ length: n }, () => Array(n).fill(0));
    for (let i = 0; i < n; i++) {
      if (values[i] > tol) {
        const inv = 1 / values[i];
        for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) P[r][c] += inv * V[r][i] * V[c][i];
      }
    }
    return P;
  }

  /* ---------------------------- 特殊函数 -------------------------------- */
  // Lanczos 近似 ln Γ
  function gammaln(xx) {
    const cof = [76.18009172947146, -86.50532032941677, 24.01409824083091,
      -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    let x = xx, y = xx;
    let tmp = x + 5.5; tmp -= (x + 0.5) * Math.log(tmp);
    let ser = 1.000000000190015;
    for (let j = 0; j < 6; j++) { y++; ser += cof[j] / y; }
    return -tmp + Math.log(2.5066282746310005 * ser / x);
  }
  // 连分式 (Numerical Recipes)
  function betacf(a, b, x) {
    const MAXIT = 200, EPS = 3e-12, FPMIN = 1e-300;
    const qab = a + b, qap = a + 1, qam = a - 1;
    let c = 1, d = 1 - qab * x / qap;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    d = 1 / d; let h = d;
    for (let m = 1; m <= MAXIT; m++) {
      const m2 = 2 * m;
      let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; h *= d * c;
      aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; const del = d * c; h *= del;
      if (Math.abs(del - 1) < EPS) break;
    }
    return h;
  }
  // 正则化不完全 Beta 函数 I_x(a,b)
  function betai(a, b, x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const bt = Math.exp(gammaln(a + b) - gammaln(a) - gammaln(b) + a * Math.log(x) + b * Math.log(1 - x));
    if (x < (a + 1) / (a + b + 2)) return bt * betacf(a, b, x) / a;
    return 1 - bt * betacf(b, a, 1 - x) / b;
  }
  // 学生 t 分布 CDF（P(T<=t)）
  function studentTCDF(t, df) {
    if (df <= 0) return NaN;
    if (!isFinite(t)) return t > 0 ? 1 : 0;
    const x = df / (df + t * t);
    if (t >= 0) return 1 - 0.5 * betai(df / 2, 0.5, x);
    return 0.5 * betai(df / 2, 0.5, x);
  }
  // 学生 t 双尾 p 值
  function tTwoTailP(t, df) {
    return 2 * (1 - studentTCDF(Math.abs(t), df));
  }
  // F 分布右尾 p 值 (P(F>f))
  function fRightP(f, p, q) {
    if (f <= 0) return 1;
    const x = p * f / (p * f + q);
    return 1 - betai(p / 2, q / 2, x);
  }

  /* ========================================================================
   * 模块 1：Plackett-Burman 筛选设计
   * =======================================================================*/
  const PB12_GEN = [1, 1, -1, 1, 1, 1, -1, -1, -1, 1, -1];

  // Sylvester 型 Hadamard 矩阵（阶为 2 的幂）
  function hadamardSylvester(order) {
    let H = [[1]];
    while (H.length < order) {
      const n = H.length;
      const next = Array.from({ length: 2 * n }, () => Array(2 * n).fill(0));
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
        next[i][j] = H[i][j];
        next[i][j + n] = H[i][j];
        next[i + n][j] = H[i][j];
        next[i + n][j + n] = -H[i][j];
      }
      H = next;
    }
    return H;
  }

  /**
   * 生成 Plackett-Burman 设计矩阵
   * @param {number} nRuns   试验次数，可选 8 / 12 / 16
   * @param {number} nFactors 因素个数，≤ nRuns-1
   * @returns {number[][]}  runs × factors，元素为 +1 / -1
   */
  function plackettBurman(nRuns, nFactors) {
    if (![8, 12, 16].includes(nRuns)) throw new Error('PB 试验次数仅支持 8 / 12 / 16');
    const maxF = nRuns - 1;
    if (nFactors < 1 || nFactors > maxF) throw new Error('因素数需在 1 ~ ' + maxF + ' 之间');

    if (nRuns === 12) {
      const gen = PB12_GEN;
      const M = Array.from({ length: 12 }, (_, r) =>
        Array.from({ length: 11 }, (_, j) => (r < 11 ? gen[(j + r) % 11] : -1)));
      return M.map((row) => row.slice(0, nFactors));
    }
    // 8 与 16：Sylvester Hadamard，去掉全 1 列，取前 nFactors 列
    const H = hadamardSylvester(nRuns);
    return H.map((row) => row.slice(1, 1 + nFactors));
  }

  /**
   * 计算 PB 主效应
   * @param {number[][]} design runs × factors (±1)
   * @param {number[]} y 各试验响应值
   */
  function pbEffects(design, y) {
    const N = design.length, k = design[0].length;
    const eff = [];
    for (let j = 0; j < k; j++) {
      let sH = 0, nH = 0, sL = 0, nL = 0;
      for (let i = 0; i < N; i++) {
        if (design[i][j] > 0) { sH += y[i]; nH++; } else { sL += y[i]; nL++; }
      }
      eff.push(sH / nH - sL / nL);
    }
    return eff;
  }

  /**
   * Lenth 法显著性检验（无重复时的伪标准误法）
   * 返回每个因素的 ME、SME、t 值与显著标记
   */
  function lenthTest(effects, alpha) {
    alpha = alpha || 0.05;
    const abs = effects.map(Math.abs);
    const ME = median(abs) / 1.5;
    const sel = abs.filter((a) => a <= 2.5 * ME).sort((a, b) => a - b);
    const SME = 1.5 * median(sel);
    // Lenth 临界值表（近似，df≈因素数）。常用临界 t 值（90% 置信，单侧）
    const criticalT = { 3: 2.41, 4: 2.37, 5: 2.34, 6: 2.33, 7: 2.31, 8: 2.30, 9: 2.29, 10: 2.28, 11: 2.27, 15: 2.25 };
    const df = effects.length;
    const tCrit = criticalT[df] || 2.25;
    const out = effects.map((e) => {
      const t = SME === 0 ? 0 : e / SME;
      return { effect: e, tLenth: t, significant: Math.abs(t) > tCrit };
    });
    return { ME, SME, tCrit, results: out };
  }

  /**
   * PB 曲率检验：对比析因点均值与中心点均值。
   * 若差异显著，说明存在曲率（二次效应），一阶 PB 结论不可靠，须用二阶设计。
   * @param {number[][]} design runs × factors (±1，中心点为全 0)
   * @param {number[]} y 响应值
   */
  function pbCurvature(design, y) {
    const fac = [], cen = [];
    design.forEach((row, i) => {
      if (row.every((v) => Math.abs(v) < 1e-9)) cen.push(y[i]);
      else fac.push(y[i]);
    });
    const facMean = mean(fac), cenMean = mean(cen);
    const curvature = facMean - cenMean; // 曲率（远离0→非线性）
    let t = 0, p = null, significant = false;
    if (cen.length >= 2) {
      const mseC = cen.reduce((s, v) => s + (v - cenMean) ** 2, 0) / (cen.length - 1);
      const se = Math.sqrt(mseC * (1 / fac.length + 1 / cen.length));
      t = se === 0 ? 0 : curvature / se;
      p = tTwoTailP(t, cen.length - 1);
      significant = p < 0.05;
    }
    return { curvature, facMean, cenMean, nF: fac.length, nC: cen.length, t, p, significant };
  }

  /**
   * 计算 2^k 个角点(±1)处的预测响应，用于边界最优点比对（BBD 不含顶点）。
   */
  function predictVertices(beta, k) {
    const out = [];
    const rec = (dim, cur) => {
      if (dim === k) { out.push({ x: cur.slice(), y: predictAt(beta, k, cur) }); return; }
      for (const v of [-1, 1]) { cur[dim] = v; rec(dim + 1, cur); }
    };
    rec(0, Array(k).fill(0));
    return out;
  }

  /**
   * 包合率蒙特卡洛不确定度传播。
   * 对输入量叠加相对正态误差，给出包合率/收率/载药量的均值、标准差与 95% 置信区间。
   * @param {{din,ein,comp,dcplx}} pars 主药投料/辅料投料/包合物质量/包合物中主药
   * @param {object} [cv] 各输入的相对标准差(默认 1%)
   */
  function monteCarloInclusion(pars, cv) {
    cv = cv || {};
    const keys = ['din', 'ein', 'comp', 'dcplx'];
    const rel = {}; keys.forEach((k) => (rel[k] = cv[k] != null ? cv[k] : 0.01));
    const N = 20000;
    const rng = (() => { let s = 987654321; return () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; }; })();
    const gauss = () => { let u = 0, v = 0; while (!u) u = rng(); while (!v) v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    const inc = [], yld = [], lod = [];
    for (let i = 0; i < N; i++) {
      const x = {}; keys.forEach((k) => { const m = pars[k]; x[k] = Math.max(0, m * (1 + rel[k] * gauss())); });
      if (x.din > 0) inc.push((x.dcplx / x.din) * 100);
      if (x.din + x.ein > 0) yld.push((x.comp / (x.din + x.ein)) * 100);
      if (x.comp > 0) lod.push((x.dcplx / x.comp) * 100);
    }
    const stats = (arr) => {
      const m = mean(arr); const sd = Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / (arr.length - 1));
      const s = arr.slice().sort((a, b) => a - b);
      return { mean: m, sd, ciLow: s[Math.floor(0.025 * arr.length)], ciHigh: s[Math.floor(0.975 * arr.length)] };
    };
    return { inclusion: stats(inc), yieldR: stats(yld), load: stats(lod), N };
  }

  /* ========================================================================
   * 模块 2：Box-Behnken 响应曲面设计 + 二阶建模
   * =======================================================================*/
  /**
   * 生成 Box-Behnken 设计矩阵
   * @param {number} k 因素数（2~5）
   * @param {number} nCenter 中心点重复数（默认 3）
   */
  function boxBehnken(k, nCenter) {
    if (k < 2 || k > 5) throw new Error('BBD 因素数需在 2 ~ 5 之间');
    nCenter = nCenter || 3;
    const pts = [];
    for (let i = 0; i < k; i++)
      for (let j = i + 1; j < k; j++)
        for (const a of [-1, 1]) for (const b of [-1, 1]) {
          const p = Array(k).fill(0);
          p[i] = a; p[j] = b;
          pts.push(p);
        }
    for (let c = 0; c < nCenter; c++) pts.push(Array(k).fill(0));
    return pts;
  }

  // 由设计矩阵构造回归模型矩阵 X（含截距、线性、平方、交互项）
  function bbdModelMatrix(design) {
    const k = design[0].length, N = design.length;
    const cols = [];
    cols.push(design.map(() => 1));                 // 截距
    for (let j = 0; j < k; j++) cols.push(design.map((r) => r[j]));        // 线性
    for (let j = 0; j < k; j++) cols.push(design.map((r) => r[j] * r[j])); // 平方
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++)
      cols.push(design.map((r) => r[i] * r[j]));    // 交互
    const p = cols.length;
    const X = Array.from({ length: N }, (_, i) => cols.map((c) => c[i]));
    return { X, p, k };
  }

  /**
   * 拟合二阶响应曲面模型并返回完整统计结果
   * @param {number[][]} design 编码后的 runs × k 设计矩阵
   * @param {number[]} y 响应值
   * @param {string[]} factorNames 因素名（用于标注系数）
   */
  function fitResponseSurface(design, y, factorNames) {
    const { X, p, k } = bbdModelMatrix(design);
    const N = X.length;
    const Xt = transpose(X);
    const XtX = matMul(Xt, X);
    const Xty = matMul(Xt, y.map((v) => [v])).map((r) => r[0]);
    const XtXinv = pinvSym(XtX);
    const beta = matMul(XtXinv, Xty.map((v) => [v])).map((r) => r[0]);

    const yhat = X.map((r) => r.reduce((s, v, j) => s + v * beta[j], 0));
    const resid = y.map((v, i) => v - yhat[i]);
    const ybar = mean(y);
    const SST = y.reduce((s, v) => s + (v - ybar) ** 2, 0);
    const SSE = resid.reduce((s, v) => s + v * v, 0);
    const SSR = SST - SSE;
    const dfR = p - 1, dfE = N - p, dfT = N - 1;
    const MSR = SSR / dfR, MSE = SSE / dfE;
    const Fmodel = MSE === 0 ? Infinity : MSR / MSE;
    const R2 = SST === 0 ? 1 : 1 - SSE / SST;
    const adjR2 = 1 - (SSE / dfE) / (SST / dfT);
    const RMSE = Math.sqrt(MSE);

    // 系数表
    const names = modelTermNames(k, factorNames);
    const coeffs = names.map((nm, j) => {
      const se = Math.sqrt(XtXinv[j][j] * MSE);
      const t = se === 0 ? 0 : beta[j] / se;
      const pval = j === 0 ? null : tTwoTailP(t, dfE); // 截距通常不做显著性检验
      return { term: nm, coef: beta[j], se, t, p: pval };
    });

    const pModel = dfE > 0 && isFinite(Fmodel) ? fRightP(Fmodel, dfR, dfE) : null;

    // 拟合不足检验（基于重复中心点）：分离纯误差与模型误差
    let lof = null;
    const cIdx = [];
    for (let i = 0; i < N; i++) if (design[i].every((v) => Math.abs(v) < 1e-9)) cIdx.push(i);
    if (cIdx.length >= 2) {
      const yc = cIdx.map((i) => y[i]);
      const ybarC = mean(yc);
      const SS_PE = yc.reduce((s, v) => s + (v - ybarC) ** 2, 0);
      const df_PE = cIdx.length - 1;
      const SS_LoF = SSE - SS_PE;
      const df_LoF = dfE - df_PE;
      const F = df_LoF > 0 ? (SS_LoF / df_LoF) / (SS_PE / df_PE) : 0;
      const p = df_LoF > 0 ? fRightP(F, df_LoF, df_PE) : null;
      lof = { nC: cIdx.length, SS_PE, df_PE, SS_LoF, df_LoF, F, p, adequate: p == null ? null : p > 0.05 };
    }

    // 角点预测（BBD 不含顶点，用于边界最优点比对）
    const vertices = predictVertices(beta, k);
    const bestVertex = vertices.reduce((a, b) => (b.y > a.y ? b : a));

    // 最优化
    const opt = optimizeSurface(beta, k);

    return {
      N, p, k, beta, coeffs, names,
      yhat, resid,
      SST, SSR, SSE, MSR, MSE, dfR, dfE, dfT,
      Fmodel, pModel, R2, adjR2, RMSE,
      lof, vertices, bestVertex,
      opt,
    };
  }

  // 模型项名称顺序：截距, x1..xk, x1²..xk², xi xj
  function modelTermNames(k, factorNames) {
    const f = factorNames || Array.from({ length: k }, (_, i) => 'X' + (i + 1));
    const names = ['截距(β0)'];
    for (let j = 0; j < k; j++) names.push(f[j] + '(线性)');
    for (let j = 0; j < k; j++) names.push(f[j] + '²(平方)');
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++) names.push(f[i] + '×' + f[j] + '(交互)');
    return names;
  }

  /**
   * 预测给定编码点处的响应
   */
  function predictAt(beta, k, x) {
    let y = beta[0];
    let idx = 1;
    for (let j = 0; j < k; j++) { y += beta[idx++] * x[j]; }
    for (let j = 0; j < k; j++) { y += beta[idx++] * x[j] * x[j]; }
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++) { y += beta[idx++] * x[i] * x[j]; }
    return y;
  }

  /**
   * 求解最优工艺：先求驻点；若驻点在[-1,1]内且为极大值则取之，否则网格搜索
   */
  function optimizeSurface(beta, k) {
    // 驻点： 2*bi_i*xi + Σ_{j≠i} bij xj = -b_i
    const lin = []; for (let j = 0; j < k; j++) lin.push(beta[1 + j]);
    const quad = []; for (let j = 0; j < k; j++) quad.push(beta[1 + k + j]);
    // 交互系数 bij 存于 offset
    let off = 1 + 2 * k;
    const inter = {};
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++) { inter[i + '_' + j] = beta[off++]; }
    const A = Array.from({ length: k }, () => Array(k).fill(0));
    const bvec = Array(k).fill(0);
    for (let i = 0; i < k; i++) {
      A[i][i] = 2 * quad[i];
      for (let j = 0; j < k; j++) if (j !== i) {
        const v = i < j ? inter[i + '_' + j] : inter[j + '_' + i];
        A[i][j] = v;
      }
      bvec[i] = -lin[i];
    }
    let stationary = null, interior = true, isMax = false;
    try {
      stationary = solveLinear(A, bvec);
      interior = stationary.every((v) => v >= -1 - 1e-9 && v <= 1 + 1e-9);
      // Hessian 负定判定（顺序主子式符号交替：|H1|<0, |H2|>0,...）
      let negDef = true;
      for (let s = 1; s <= k; s++) {
        const sub = A.slice(0, s).map((r) => r.slice(0, s));
        const det = determinant(sub);
        const expected = (s % 2 === 1) ? -1 : 1; // 负定要求 (-1)^s * det > 0
        if (expected * det <= 0) { negDef = false; break; }
      }
      isMax = negDef;
    } catch (e) { stationary = null; }

    // 网格搜索（稳健，无论是否凸）
    const step = 0.05;
    let best = { y: -Infinity, x: null };
    const grid1 = [];
    for (let v = -1; v <= 1.0001; v += step) grid1.push(Math.round(v * 1000) / 1000);
    const rec = (dim, cur) => {
      if (dim === k) {
        const yv = predictAt(beta, k, cur);
        if (yv > best.y) best = { y: yv, x: cur.slice() };
        return;
      }
      for (const v of grid1) { cur[dim] = v; rec(dim + 1, cur); }
    };
    rec(0, Array(k).fill(0));

    const useStationary = stationary && interior && isMax;
    return {
      stationary,
      stationaryInterior: interior,
      stationaryIsMax: isMax,
      recommended: useStationary ? stationary.slice() : best.x,
      recommendedY: useStationary ? predictAt(beta, k, stationary) : best.y,
      method: useStationary ? '驻点(二阶导数负定,区域内)' : '网格搜索(区域内最大值)',
    };
  }
  function determinant(M) {
    const n = M.length;
    if (n === 1) return M[0][0];
    if (n === 2) return M[0][0] * M[1][1] - M[0][1] * M[1][0];
    let det = 0;
    for (let c = 0; c < n; c++) {
      const sub = M.slice(1).map((r) => r.filter((_, j) => j !== c));
      det += ((c % 2 === 0) ? 1 : -1) * M[0][c] * determinant(sub);
    }
    return det;
  }

  // 编码 → 实际值（实际 = 低 + (编码+1)/2 * (高-低)）
  function codedToActual(coded, lows, highs) {
    return coded.map((v, j) => lows[j] + (v + 1) / 2 * (highs[j] - lows[j]));
  }

  /* ---------------------------- 导出 ------------------------------------ */
  const API = {
    median, mean, transpose, matMul, matInv, solveLinear,
    gammaln, betai, studentTCDF, tTwoTailP, fRightP, pinvSym, jacobiEigen,
    plackettBurman, pbEffects, lenthTest, pbCurvature, hadamardSylvester,
    boxBehnken, bbdModelMatrix, fitResponseSurface, predictAt, optimizeSurface,
    predictVertices, codedToActual, modelTermNames, monteCarloInclusion,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.MathLib = API;
})(typeof window !== 'undefined' ? window : globalThis);
