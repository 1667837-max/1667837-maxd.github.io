/* =============================================================================
 * app.js — 药品包合工艺优化实验软件 · 前端交互
 * 依赖：mathlib.js (window.MathLib)
 * ===========================================================================*/
(function () {
  'use strict';
  const ML = window.MathLib;
  const $ = (id) => document.getElementById(id);
  const fmt = (x, d) => (x === null || x === undefined || isNaN(x)) ? '—' : Number(x).toFixed(d === undefined ? 3 : d);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ----------------------------- Toast ------------------------------ */
  let toastTimer = null;
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ----------------------------- Tabs ------------------------------- */
  document.querySelectorAll('nav.tabs button').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('nav.tabs button').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
      btn.classList.add('active');
      $('view-' + btn.dataset.view).classList.add('active');
    });
  });

  /* ============================ 模块一：PB ============================ */
  const pbState = { factors: [], design: [], responses: [], lenth: null };
  const DEFAULT_PB = [
    { name: '搅拌时间(min)', low: 30, high: 60 },
    { name: '温度(℃)', low: 40, high: 60 },
    { name: '转速(rpm)', low: 200, high: 400 },
  ];

  function renderPbFactors() {
    const box = $('pb-factors'); box.innerHTML = '';
    pbState.factors.forEach((f, i) => {
      const div = document.createElement('div'); div.className = 'field';
      div.innerHTML =
        '<label>因素 ' + (i + 1) + ' 名称</label>' +
        '<input value="' + f.name + '" data-i="' + i + '" data-k="name" />' +
        '<div class="row" style="margin-top:4px">' +
        '<input type="number" step="any" value="' + f.low + '" data-i="' + i + '" data-k="low" placeholder="低(-1)" style="width:46%"/>' +
        '<input type="number" step="any" value="' + f.high + '" data-i="' + i + '" data-k="high" placeholder="高(+1)" style="width:46%"/>' +
        '</div>';
      box.appendChild(div);
    });
    box.querySelectorAll('input').forEach((inp) => {
      inp.addEventListener('input', () => {
        const i = +inp.dataset.i, k = inp.dataset.k;
        pbState.factors[i][k] = (k === 'name') ? inp.value : parseFloat(inp.value);
      });
    });
  }
  $('pb-add').addEventListener('click', () => {
    if (pbState.factors.length >= 15) return toast('PB 最多 15 个因素');
    pbState.factors.push({ name: '因素' + (pbState.factors.length + 1), low: 0, high: 1 });
    renderPbFactors();
  });
  $('pb-del').addEventListener('click', () => {
    if (pbState.factors.length <= 1) return toast('至少保留 1 个因素');
    pbState.factors.pop(); renderPbFactors();
  });

  $('pb-gen').addEventListener('click', () => {
    const runs = +$('pb-runs').value;
    const k = pbState.factors.length;
    if (k > runs - 1) return toast('因素数 ' + k + ' 超过 ' + runs + ' 次设计上限（' + (runs - 1) + '）');
    const c = +$('pb-center').value;
    let design = ML.plackettBurman(runs, k);
    for (let i = 0; i < c; i++) design.push(Array(k).fill(0));
    pbState.design = design;
    pbState.responses = design.map(() => NaN);
    const lows = pbState.factors.map((f) => f.low);
    const highs = pbState.factors.map((f) => f.high);
    const names = pbState.factors.map((f) => f.name);
    let html = '<table><thead><tr><th>试验号</th>';
    names.forEach((n) => html += '<th>' + n + '<br>(编码)</th>');
    names.forEach((n) => html += '<th>' + n + '<br>(实际)</th>');
    html += '<th>响应值</th></tr></thead><tbody>';
    pbState.design.forEach((row, i) => {
      const isC = row.every((v) => v === 0);
      html += '<tr' + (isC ? ' style="background:#f0f7f3"' : '') + '><td>' + (i + 1) + (isC ? '(中)' : '') + '</td>';
      row.forEach((v) => html += '<td>' + (v > 0 ? '+1' : v < 0 ? '−1' : '0') + '</td>');
      row.forEach((v, j) => {
        const act = lows[j] + (v + 1) / 2 * (highs[j] - lows[j]);
        html += '<td>' + fmt(act, 2) + '</td>';
      });
      html += '<td><input id="pb-y-' + i + '" type="number" step="any" placeholder="录入响应" /></td></tr>';
    });
    html += '</tbody></table>';
    $('pb-design-table').innerHTML = html;
    $('pb-design-card').style.display = 'block';
    $('pb-result-card').style.display = 'none';
    $('pb-to-bbd').disabled = true;
    toast('已生成 ' + runs + ' 次 Plackett-Burman 方案');
  });

  $('pb-analyze').addEventListener('click', () => {
    const y = pbState.design.map((_, i) => parseFloat($('pb-y-' + i).value));
    if (y.some((v) => isNaN(v))) return toast('请完整录入所有响应值');
    pbState.responses = y;
    const eff = ML.pbEffects(pbState.design, y);
    const lent = ML.lenthTest(eff);
    pbState.lenth = lent;
    const curv = ML.pbCurvature(pbState.design, y);
    const cvBox = $('pb-curv'); cvBox.style.display = 'block';
    cvBox.innerHTML = '<b>曲率检验：</b>析因点均值 ' + fmt(curv.facMean, 3) + '，中心点均值 ' + fmt(curv.cenMean, 3) +
      '，曲率 = ' + fmt(curv.curvature, 3) + '。' +
      (curv.significant ? '<span class="warn-txt">曲率显著（p=' + fmt(curv.p, 3) + '）：存在非线性，一阶 PB 可能误删具二次效应的因素，必须接力曲面寻优。</span>'
                        : '曲率不显著，一阶近似可接受。');
    const names = pbState.factors.map((f) => f.name);
    // 排序
    const order = eff.map((e, i) => ({ i, e })).sort((a, b) => Math.abs(b.e) - Math.abs(a.e));
    let html = '<table><thead><tr><th>排序</th><th>因素</th><th>主效应</th><th>|效应|</th><th>Lenth t</th><th>显著性</th></tr></thead><tbody>';
    order.forEach((o, rank) => {
      const r = lent.results[o.i];
      html += '<tr><td>' + (rank + 1) + '</td><td>' + names[o.i] + '</td><td>' + fmt(o.e, 4) +
        '</td><td>' + fmt(Math.abs(o.e), 4) + '</td><td>' + fmt(r.tLenth, 3) +
        '</td><td><span class="pill ' + (r.significant ? 'sig' : 'ns') + '">' +
        (r.significant ? '显著' : '不显著') + '</span></td></tr>';
    });
    html += '</tbody></table>';
    html += '<div class="hint">ME=' + fmt(lent.ME, 4) + '，SME=' + fmt(lent.SME, 4) + '，临界 t(' + eff.length + ')=' + fmt(lent.tCrit, 2) + '</div>';
    $('pb-effect-table').innerHTML = html;

    // Pareto
    drawPareto($('pb-pareto'), order.map((o) => ({ name: names[o.i], e: o.e })), lent.tCrit * lent.SME);

    const sig = order.filter((o) => lent.results[o.i].significant).map((o) => o.i);
    const reco = $('pb-reco');
    const bText = sig.length ? '<br><span class="warn-txt">改进提示（边界最优点预警）：' +
      sig.map((i) => names[i] + (eff[i] > 0 ? ' 效应为正，最优或在本范围高侧之外' : ' 效应为负，最优或在本范围低侧之外')).join('；') +
      '。若后续曲面寻优最优点贴边，建议扩界复筛。</span>' : '';
    if (sig.length) {
      reco.style.display = 'block';
      reco.innerHTML = '<b>筛选结论：</b>显著影响包合率的因素为 <b>' +
        sig.map((i) => names[i]).join('、') + '</b>（共 ' + sig.length + ' 个）。建议将其作为关键因素进入曲面寻优。' + bText;
      $('pb-to-bbd').disabled = false;
    } else {
      reco.style.display = 'block';
      reco.innerHTML = '<b>筛选结论：</b>本次试验未检出显著因素（可能效应较弱或噪声偏大）。如需继续，可将全部因素传入曲面寻优进一步考察。';
      $('pb-to-bbd').disabled = false;
    }
    $('pb-result-card').style.display = 'block';
  });

  $('pb-to-bbd').addEventListener('click', () => {
    const names = pbState.factors.map((f) => f.name);
    let idx;
    if (pbState.lenth) {
      idx = pbState.design[0].map((_, j) => j).filter((j) => pbState.lenth.results[j].significant);
      if (!idx.length) idx = pbState.factors.map((_, j) => j);
    } else idx = pbState.factors.map((_, j) => j);
    bbdState.factors = idx.map((j) => ({ name: names[j], low: pbState.factors[j].low, high: pbState.factors[j].high }));
    if (bbdState.factors.length < 2) {
      // BBD 至少 2 因素，补足
      while (bbdState.factors.length < 2) bbdState.factors.push({ name: '补充因素' + bbdState.factors.length, low: 0, high: 1 });
    }
    if (bbdState.factors.length > 5) bbdState.factors = bbdState.factors.slice(0, 5);
    renderBbdFactors();
    document.querySelectorAll('nav.tabs button').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    document.querySelector('nav.tabs button[data-view="bbd"]').classList.add('active');
    $('view-bbd').classList.add('active');
    toast('已将 ' + bbdState.factors.length + ' 个因素传入曲面寻优');
  });

  function drawPareto(canvas, data, critLine) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height, pad = 40;
    ctx.clearRect(0, 0, W, H);
    const maxAbs = Math.max(...data.map((d) => Math.abs(d.e)), critLine, 1e-9);
    const baseY = H - pad, topY = pad;
    // 轴线
    ctx.strokeStyle = '#cbd5e1'; ctx.beginPath();
    ctx.moveTo(pad, topY); ctx.lineTo(pad, baseY); ctx.lineTo(W - 10, baseY); ctx.stroke();
    // 临界线
    const critY = baseY - (critLine / maxAbs) * (baseY - topY);
    ctx.strokeStyle = '#c0392b'; ctx.setLineDash([5, 4]); ctx.beginPath();
    ctx.moveTo(pad, critY); ctx.lineTo(W - 10, critY); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#c0392b'; ctx.font = '11px sans-serif';
    ctx.fillText('显著临界', W - 70, critY - 4);
    const bw = (W - pad - 10) / data.length;
    data.forEach((d, i) => {
      const h = (Math.abs(d.e) / maxAbs) * (baseY - topY);
      const x = pad + i * bw + bw * 0.15;
      const y = d.e >= 0 ? baseY - h : baseY;
      ctx.fillStyle = d.e >= 0 ? '#2b6cb0' : '#2c7a5b';
      ctx.fillRect(x, y, bw * 0.7, d.e >= 0 ? h : -h);
      ctx.fillStyle = '#1f2a44'; ctx.font = '10px sans-serif';
      ctx.save(); ctx.translate(x + bw * 0.35, baseY + 12); ctx.rotate(-Math.PI / 4);
      ctx.textAlign = 'right'; ctx.fillText(d.name, 0, 0); ctx.restore();
      ctx.textAlign = 'center';
      ctx.fillText(fmt(d.e, 2), x + bw * 0.35, (d.e >= 0 ? baseY - h - 4 : baseY + h + 12));
    });
  }

  /* ========================= 模块二：BBD ========================== */
  const bbdState = { factors: [], design: [], fit: null };
  function renderBbdFactors() {
    const box = $('bbd-factors'); box.innerHTML = '';
    bbdState.factors.forEach((f, i) => {
      const div = document.createElement('div'); div.className = 'field';
      div.innerHTML =
        '<label>因素 ' + (i + 1) + ' 名称</label>' +
        '<input value="' + f.name + '" data-i="' + i + '" data-k="name" />' +
        '<div class="row" style="margin-top:4px">' +
        '<input type="number" step="any" value="' + f.low + '" data-i="' + i + '" data-k="low" placeholder="低(-1)" style="width:46%"/>' +
        '<input type="number" step="any" value="' + f.high + '" data-i="' + i + '" data-k="high" placeholder="高(+1)" style="width:46%"/>' +
        '</div>';
      box.appendChild(div);
    });
    box.querySelectorAll('input').forEach((inp) => {
      inp.addEventListener('input', () => {
        const i = +inp.dataset.i, k = inp.dataset.k;
        bbdState.factors[i][k] = (k === 'name') ? inp.value : parseFloat(inp.value);
      });
    });
  }
  $('bbd-add').addEventListener('click', () => {
    if (bbdState.factors.length >= 5) return toast('BBD 最多 5 个因素');
    bbdState.factors.push({ name: '因素' + (bbdState.factors.length + 1), low: 0, high: 1 });
    renderBbdFactors();
  });
  $('bbd-del').addEventListener('click', () => {
    if (bbdState.factors.length <= 2) return toast('BBD 至少 2 个因素');
    bbdState.factors.pop(); renderBbdFactors();
  });

  $('bbd-gen').addEventListener('click', () => {
    const k = bbdState.factors.length;
    const c = +$('bbd-center').value;
    if (k < 2 || k > 5) return toast('BBD 因素数需在 2–5 之间');
    bbdState.design = ML.boxBehnken(k, c);
    const lows = bbdState.factors.map((f) => f.low);
    const highs = bbdState.factors.map((f) => f.high);
    const names = bbdState.factors.map((f) => f.name);
    let html = '<table><thead><tr><th>试验号</th>';
    names.forEach((n) => html += '<th>' + n + '<br>(编码)</th>');
    names.forEach((n) => html += '<th>' + n + '<br>(实际)</th>');
    html += '<th>响应值</th></tr></thead><tbody>';
    bbdState.design.forEach((row, i) => {
      const isC = row.every((v) => v === 0);
      html += '<tr' + (isC ? ' style="background:#f0f7f3"' : '') + '><td>' + (i + 1) + (isC ? '(中)' : '') + '</td>';
      row.forEach((v) => html += '<td>' + (v > 0 ? '+1' : v < 0 ? '−1' : '0') + '</td>');
      row.forEach((v, j) => {
        const act = lows[j] + (v + 1) / 2 * (highs[j] - lows[j]);
        html += '<td>' + fmt(act, 2) + '</td>';
      });
      html += '<td><input id="bbd-y-' + i + '" type="number" step="any" placeholder="录入响应" /></td></tr>';
    });
    html += '</tbody></table>';
    $('bbd-design-table').innerHTML = html;
    $('bbd-design-card').style.display = 'block';
    $('bbd-result-card').style.display = 'none';
    toast('已生成 ' + bbdState.design.length + ' 次 Box-Behnken 方案');
  });

  $('bbd-fit').addEventListener('click', () => {
    const y = bbdState.design.map((_, i) => parseFloat($('bbd-y-' + i).value));
    if (y.some((v) => isNaN(v))) return toast('请完整录入所有响应值');
    const names = bbdState.factors.map((f) => f.name);
    const fit = ML.fitResponseSurface(bbdState.design, y, names);
    bbdState.fit = fit;

    // 方程
    let eq = 'Y = ' + fmt(fit.beta[0], 4);
    let idx = 1;
    for (let j = 0; j < fit.k; j++) { eq += ' ' + sign(fit.beta[idx]) + ' ' + fmt(Math.abs(fit.beta[idx]), 4) + '·' + names[j]; idx++; }
    for (let j = 0; j < fit.k; j++) { eq += ' ' + sign(fit.beta[idx]) + ' ' + fmt(Math.abs(fit.beta[idx]), 4) + '·' + names[j] + '²'; idx++; }
    for (let i = 0; i < fit.k; i++) for (let j = i + 1; j < fit.k; j++) { eq += ' ' + sign(fit.beta[idx]) + ' ' + fmt(Math.abs(fit.beta[idx]), 4) + '·' + names[i] + names[j]; idx++; }
    $('bbd-eq').textContent = eq;

    // 汇总
    $('bbd-summary').innerHTML =
      kpi('样本数', fit.N, '') +
      kpi('R²', fmt(fit.R2, 4), fit.R2 > 0.8 ? 'good' : 'warn') +
      kpi('调整 R²', fmt(fit.adjR2, 4), fit.adjR2 > 0.7 ? 'good' : 'warn') +
      kpi('RMSE', fmt(fit.RMSE, 4), '') +
      kpi('模型 F', fmt(fit.Fmodel, 2), '') +
      kpi('模型 p', fit.pModel === null ? '—' : fmt(fit.pModel, 4), (fit.pModel !== null && fit.pModel < 0.05) ? 'good' : 'warn');

    // ANOVA
    $('bbd-anova').innerHTML =
      '<table><thead><tr><th>来源</th><th>平方和 SS</th><th>自由度 df</th><th>均方 MS</th><th>F 值</th><th>p 值</th><th>显著性</th></tr></thead><tbody>' +
      anovaRow('回归(模型)', fit.SSR, fit.dfR, fit.MSR, fit.Fmodel, fit.pModel) +
      anovaRow('残差', fit.SSE, fit.dfE, fit.MSE, null, null) +
      anovaRow('总计', fit.SST, fit.dfT, null, null, null) +
      '</tbody></table>';

    // 系数
    let ch = '<table><thead><tr><th>项</th><th>系数</th><th>标准误</th><th>t 值</th><th>p 值</th><th>显著性</th></tr></thead><tbody>';
    fit.coeffs.forEach((c) => {
      ch += '<tr><td>' + c.term + '</td><td>' + fmt(c.coef, 4) + '</td><td>' + fmt(c.se, 4) +
        '</td><td>' + fmt(c.t, 3) + '</td><td>' + (c.p === null ? '—' : fmt(c.p, 4)) +
        '</td><td>' + (c.p === null ? '—' : '<span class="pill ' + (c.p < 0.05 ? 'sig' : 'ns') + '">' + (c.p < 0.05 ? '显著' : '不显著') + '</span>') + '</td></tr>';
    });
    ch += '</tbody></table>';
    $('bbd-coeff').innerHTML = ch;

    // 最优
    const lows = bbdState.factors.map((f) => f.low), highs = bbdState.factors.map((f) => f.high);
    const recAct = ML.codedToActual(fit.opt.recommended, lows, highs);

    // 模型诊断：拟合不足检验(LoF) + 边界最优点
    const diag = $('bbd-diag');
    let dg = '<b>拟合不足检验(LoF)：</b>';
    if (fit.lof) {
      dg += 'F=' + fmt(fit.lof.F, 3) + '，p=' + fmt(fit.lof.p, 4) + ' → ' +
        (fit.lof.adequate ? '<span class="ok-txt">模型充分（无显著拟合不足）</span>'
                          : '<span class="warn-txt">存在显著拟合不足，二次模型可能不足，需考虑更高阶模型或核查数据</span>') + '。';
    } else {
      dg += '中心点重复 &lt; 2，无法进行 LoF 检验（建议增加中心点重复）。';
    }
    const bv = fit.bestVertex;
    const bvAct = ML.codedToActual(bv.x, lows, highs);
    dg += '<br><b>边界最优点诊断：</b>2^' + fit.k + ' 角点中预测最高 = ' + fmt(bv.y, 3) +
      '（' + names.map((n, j) => n + '=' + fmt(bvAct[j], 2)).join('，') + '）；内部驻点预测 = ' + fmt(fit.opt.recommendedY, 3) + '。';
    if (bv.y > fit.opt.recommendedY + 1e-6) {
      dg += ' <span class="warn-txt">⚠ 角点优于内部驻点，真实最优可能在设计空间<b>边界</b>，内部驻点非全局最优，建议补做顶点验证。</span>';
    } else {
      dg += ' 内部驻点优于所有角点，可视为区域内最优。';
    }
    diag.innerHTML = dg;
    let optHtml = '<b>推荐最优工艺（' + fit.opt.method + '）：</b><br><table style="width:auto"><thead><tr><th>因素</th><th>编码值</th><th>实际水平</th></tr></thead><tbody>';
    names.forEach((n, j) => {
      optHtml += '<tr><td>' + n + '</td><td>' + fmt(fit.opt.recommended[j], 3) + '</td><td>' + fmt(recAct[j], 3) + '</td></tr>';
    });
    optHtml += '</tbody></table><br>预测响应值（包合率等）：<b>' + fmt(fit.opt.recommendedY, 3) + '</b>';
    if (!fit.opt.stationaryInterior) optHtml += '<br><span class="muted">注：二阶模型驻点落在设计空间外，已采用空间内网格搜索取得最大值。</span>';
    $('bbd-opt').innerHTML = optHtml;

    // 可视化控件
    const sx = $('viz-x'), sy = $('viz-y');
    sx.innerHTML = ''; sy.innerHTML = '';
    names.forEach((n, j) => {
      sx.innerHTML += '<option value="' + j + '"' + (j === 0 ? ' selected' : '') + '>' + n + '</option>';
      sy.innerHTML += '<option value="' + j + '"' + (j === 1 ? ' selected' : '') + '>' + n + '</option>';
    });
    $('viz-z-wrap').style.display = (fit.k >= 3) ? 'flex' : 'none';
    drawViz();
    $('bbd-result-card').style.display = 'block';
    toast('建模完成，R²=' + fmt(fit.R2, 3));
  });

  function sign(v) { return v >= 0 ? '+' : '−'; }
  function kpi(label, value, cls) {
    return '<div class="kpi ' + (cls || '') + '"><div class="v">' + value + '</div><div class="l">' + label + '</div></div>';
  }
  function anovaRow(src, ss, df, ms, f, p) {
    return '<tr><td>' + src + '</td><td>' + fmt(ss, 3) + '</td><td>' + (df === null ? '—' : df) +
      '</td><td>' + (ms === null ? '—' : fmt(ms, 3)) + '</td><td>' + (f === null ? '—' : fmt(f, 2)) +
      '</td><td>' + (p === null ? '—' : fmt(p, 4)) + '</td><td>' +
      (p === null ? '—' : '<span class="pill ' + (p < 0.05 ? 'sig' : 'ns') + '">' + (p < 0.05 ? '显著' : '不显著') + '</span>') + '</td></tr>';
  }

  /* --------------------- 可视化（曲面 + 等高线） --------------------- */
  function drawViz() {
    const fit = bbdState.fit; if (!fit) return;
    const k = fit.k;
    const ix = +$('viz-x').value, iy = +$('viz-y').value;
    let iz = (k >= 3) ? Math.min(2, k - 1) : -1;
    // 找第三个不同于 ix,iy 的索引
    if (k >= 3) { for (let j = 0; j < k; j++) if (j !== ix && j !== iy) { iz = j; break; } }
    const zval = ($('viz-z').value === '') ? 0 : parseFloat($('viz-z').value);
    const az = (+$('viz-rot').value) * Math.PI / 180;

    // 采样
    const N = 18, gridVal = [], gx = [], gy = [];
    let zmin = Infinity, zmax = -Infinity;
    for (let a = 0; a < N; a++) {
      gx[a] = -1 + 2 * a / (N - 1);
      gy[a] = -1 + 2 * a / (N - 1);
    }
    for (let a = 0; a < N; a++) {
      gridVal[a] = [];
      for (let b = 0; b < N; b++) {
        const x = Array(k).fill(0);
        x[ix] = gx[a]; x[iy] = gy[b]; if (iz >= 0) x[iz] = zval;
        const z = ML.predictAt(fit.beta, k, x);
        gridVal[a][b] = z; if (z < zmin) zmin = z; if (z > zmax) zmax = z;
      }
    }
    drawSurface($('bbd-surface'), gridVal, gx, gy, az, zmin, zmax);
    drawContour($('bbd-contour'), gridVal, gx, gy, zmin, zmax);
  }
  ['viz-x', 'viz-y', 'viz-z', 'viz-rot'].forEach((id) => $(id).addEventListener('input', drawViz));

  function cmap(t) { t = clamp(t, 0, 1); const h = (1 - t) * 220; return 'hsl(' + h.toFixed(0) + ',68%,55%)'; }

  function drawSurface(canvas, G, gx, gy, az, zmin, zmax) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    const cx = W / 2, cy = H * 0.58, s = 78, tilt = 0.5;
    const N = G.length;
    const zr = (zmax - zmin) || 1;
    const proj = (x, y, z) => {
      const ct = Math.cos(tilt), st = Math.sin(tilt);
      const y1 = y * ct - z * st, z1 = y * st + z * ct;
      const ca = Math.cos(az), sa = Math.sin(az);
      const x2 = x * ca - y1 * sa, y2 = x * sa + y1 * ca;
      return { sx: cx + x2 * s, sy: cy - y2 * s, depth: z1 };
    };
    // 网格线（行、列）
    const P = [];
    for (let a = 0; a < N; a++) { P[a] = []; for (let b = 0; b < N; b++) { const z = (G[a][b] - zmin) / zr - 0.5; P[a][b] = proj(gx[a], gy[b], z * 1.3); } }
    for (let a = 0; a < N; a++) {
      for (let b = 0; b < N - 1; b++) {
        line(ctx, P[a][b], P[a][b + 1], cmap(((G[a][b] + G[a][b + 1]) / 2 - zmin) / zr));
      }
    }
    for (let b = 0; b < N; b++) {
      for (let a = 0; a < N - 1; a++) {
        line(ctx, P[a][b], P[a + 1][b], cmap(((G[a][b] + G[a + 1][b]) / 2 - zmin) / zr));
      }
    }
    // 轴标注
    ctx.fillStyle = '#6b7894'; ctx.font = '11px sans-serif';
    ctx.fillText('X: ' + bbdState.factors[+$('viz-x').value].name, 8, H - 10);
    ctx.fillText('Y: ' + bbdState.factors[+$('viz-y').value].name, W - 120, H - 10);
  }
  function line(ctx, p1, p2, color) {
    ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.beginPath();
    ctx.moveTo(p1.sx, p1.sy); ctx.lineTo(p2.sx, p2.sy); ctx.stroke();
  }

  function drawContour(canvas, G, gx, gy, zmin, zmax) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height, pad = 30;
    ctx.clearRect(0, 0, W, H);
    const N = G.length;
    const zr = (zmax - zmin) || 1;
    const bands = 10;
    const gw = (W - 2 * pad) / (N - 1), gh = (H - 2 * pad) / (N - 1);
    let maxA = 0, maxB = 0, maxZ = -Infinity;
    for (let a = 0; a < N - 1; a++) for (let b = 0; b < N - 1; b++) {
      const avg = (G[a][b] + G[a + 1][b] + G[a][b + 1] + G[a + 1][b + 1]) / 4;
      const t = (avg - zmin) / zr;
      ctx.fillStyle = cmap(t);
      ctx.fillRect(pad + a * gw, pad + b * gh, gw + 1, gh + 1);
      if (avg > maxZ) { maxZ = avg; maxA = a; maxB = b; }
    }
    // 最佳点标记
    ctx.strokeStyle = '#1f2a44'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(pad + maxA * gw, pad + maxB * gh, 5, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#1f2a44'; ctx.font = '11px sans-serif'; ctx.fillText('★最优', pad + maxA * gw + 7, pad + maxB * gh - 6);
    // 边框与刻度
    ctx.strokeStyle = '#cbd5e1'; ctx.strokeRect(pad, pad, W - 2 * pad, H - 2 * pad);
    ctx.fillStyle = '#6b7894'; ctx.font = '10px sans-serif';
    ctx.fillText(bbdState.factors[+$('viz-x').value].name + ' 低', pad, H - 12);
    ctx.fillText('高', W - pad - 14, H - 12);
    ctx.save(); ctx.translate(10, pad + 4); ctx.rotate(-Math.PI / 2); ctx.fillText('高', 0, 0); ctx.restore();
    ctx.save(); ctx.translate(10, H - pad); ctx.rotate(-Math.PI / 2); ctx.fillText(bbdState.factors[+$('viz-y').value].name + ' 低', 0, 0); ctx.restore();
    // 颜色条
    const bx = W - 16, by = pad, bh = H - 2 * pad, bw = 8;
    for (let i = 0; i < bh; i++) { ctx.fillStyle = cmap(1 - i / bh); ctx.fillRect(bx, by + i, bw, 1); }
    ctx.fillStyle = '#6b7894'; ctx.font = '9px sans-serif';
    ctx.fillText(fmt(zmax, 1), bx - 2, by + 8); ctx.fillText(fmt(zmin, 1), bx - 2, by + bh);
  }

  /* ========================= 模块三：包合率 ========================= */
  const rateHistory = [];
  function calcRate() {
    const din = parseFloat($('r-drug-in').value);
    const ein = parseFloat($('r-exc-in').value);
    const comp = parseFloat($('r-complex').value);
    const dcplx = parseFloat($('r-drug-cplx').value);
    const mother = $('r-drug-mother').value === '' ? null : parseFloat($('r-drug-mother').value);
    const def = $('r-def').value;
    if ([din, ein, comp, dcplx].some((v) => isNaN(v))) return toast('请填写主药投料、辅料投料、包合物质量、包合物中主药量');
    let inclusion;
    if (def === 'rec' && mother !== null) {
      const denom = din - mother;
      inclusion = denom > 0 ? (dcplx / denom) * 100 : NaN;
    } else {
      inclusion = (dcplx / din) * 100;
    }
    const yieldR = (comp / (din + ein)) * 100;        // 收率
    const load = (dcplx / comp) * 100;                // 载药量
    const util = ((comp - dcplx) / ein) * 100;        // 辅料利用率
    const warn = [];
    if (isNaN(inclusion)) warn.push('回收校正分母非正（母液主药 ≥ 投料主药），请核对数据。');
    else if (inclusion > 100) warn.push('包合率 > 100%，请复核包合物中主药测定量或投料量。');
    if (yieldR > 100) warn.push('收率 > 100%，可能包合物未充分干燥或称量误差。');
    if (load > 100) warn.push('载药量 > 100%，数据异常。');
    let recovery = null;
    if (mother !== null) {
      recovery = ((dcplx + mother) / din) * 100;
      if (Math.abs(recovery - 100) > 5) warn.push('物料平衡回收率 = ' + fmt(recovery, 1) + '%，偏离 100% 较多，存在过程损失或测定误差，建议核查。');
    }
    let kpis = '';
    kpis += kpi('包合率' + (def === 'rec' ? '(校正)' : ''), fmt(inclusion, 2) + '%', !isNaN(inclusion) && inclusion > 0 && inclusion <= 100 ? 'good' : 'bad');
    kpis += kpi('收率', fmt(yieldR, 2) + '%', yieldR > 0 && yieldR <= 100 ? 'good' : 'warn');
    kpis += kpi('载药量', fmt(load, 2) + '%', load > 0 && load <= 100 ? 'good' : 'warn');
    kpis += kpi('辅料利用率', fmt(util, 2) + '%', util > 0 && util <= 100 ? 'good' : 'warn');
    if (recovery !== null) kpis += kpi('物料回收率', fmt(recovery, 1) + '%', Math.abs(recovery - 100) <= 5 ? 'good' : 'warn');
    $('r-kpis').innerHTML = kpis;
    $('r-warn').innerHTML = warn.map((w) => '⚠ ' + w).join('<br>');
    $('r-out').style.display = 'block';
    return { din, ein, comp, dcplx, mother, def, inclusion, yieldR, load, util, recovery };
  }
  $('r-calc').addEventListener('click', calcRate);
  $('r-mc').addEventListener('click', () => {
    const r = calcRate(); if (!r) return;
    const cvv = (parseFloat($('r-cv').value) || 1) / 100;
    const mc = ML.monteCarloInclusion({ din: r.din, ein: r.ein, comp: r.comp, dcplx: r.dcplx }, { din: cvv, ein: cvv, comp: cvv, dcplx: cvv });
    const box = $('r-mc-out'); box.style.display = 'block';
    box.innerHTML = '<b>蒙特卡洛不确定度（N=' + mc.N + '，输入 CV=' + fmt(cvv * 100, 1) + '%）：</b><br>' +
      '包合率 95% 置信区间 = [' + fmt(mc.inclusion.ciLow, 2) + '%, ' + fmt(mc.inclusion.ciHigh, 2) + '%]，均值 ' + fmt(mc.inclusion.mean, 2) + ' ± ' + fmt(mc.inclusion.sd, 2) + '%<br>' +
      '收率 95% 置信区间 = [' + fmt(mc.yieldR.ciLow, 2) + '%, ' + fmt(mc.yieldR.ciHigh, 2) + '%]<br>' +
      '载药量 95% 置信区间 = [' + fmt(mc.load.ciLow, 2) + '%, ' + fmt(mc.load.ciHigh, 2) + '%]';
  });
  $('r-save').addEventListener('click', () => {
    const r = calcRate(); if (!r) return;
    rateHistory.push(r);
    renderHistory(); toast('已保存记录');
  });
  $('r-clear').addEventListener('click', () => {
    ['r-drug-in', 'r-exc-in', 'r-complex', 'r-drug-cplx', 'r-drug-mother'].forEach((id) => $(id).value = '');
    $('r-out').style.display = 'none';
  });
  function renderHistory() {
    if (!rateHistory.length) { $('r-history').innerHTML = '<div class="hint">暂无记录</div>'; return; }
    let html = '<table><thead><tr><th>#</th><th>主药投料</th><th>辅料投料</th><th>包合物</th><th>包合物中主药</th><th>包合率</th><th>收率</th><th>载药量</th></tr></thead><tbody>';
    rateHistory.forEach((r, i) => {
      const bad = (r.inclusion > 100 || r.inclusion < 0);
      html += '<tr class="' + (bad ? 'badrow' : '') + '"><td>' + (i + 1) + '</td><td>' + fmt(r.din, 1) + '</td><td>' + fmt(r.ein, 1) + '</td><td>' + fmt(r.comp, 1) +
        '</td><td>' + fmt(r.dcplx, 1) + '</td><td>' + fmt(r.inclusion, 2) + '%</td><td>' + fmt(r.yieldR, 2) + '%</td><td>' + fmt(r.load, 2) + '%</td></tr>';
    });
    html += '</tbody></table>';
    const incs = rateHistory.map((r) => r.inclusion);
    const mean = ML.mean(incs);
    const sd = Math.sqrt(incs.reduce((s, v) => s + (v - mean) ** 2, 0) / (incs.length - 1 || 1));
    const rsd = mean !== 0 ? sd / Math.abs(mean) * 100 : 0;
    html += '<div class="hint" style="margin-top:8px">批次统计：n=' + incs.length + '，包合率均值 ' + fmt(mean, 2) + '%，RSD ' + fmt(rsd, 2) +
      '%（RSD 越小批次越稳定；红色行表示包合率超 0–100% 异常范围）。</div>';
    $('r-history').innerHTML = html;
  }

  /* ----------------------------- 初始化 ----------------------------- */
  renderPbFactors();
  renderBbdFactors();
  renderHistory();
})();
